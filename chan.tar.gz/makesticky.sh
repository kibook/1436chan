#!/bin/bash

mv $1 sticky_$1
